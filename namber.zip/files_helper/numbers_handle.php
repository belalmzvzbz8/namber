<?php


$numbers_db     = new dataBase('numbers.json');
$NUMBERS         = $numbers_db->fetch_data();

?>