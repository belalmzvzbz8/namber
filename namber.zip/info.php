<?php


$bot_API_KEY          = '6597687087:AAFYyNJ7JJHGF1EQXnJGClpeSIqiNykcaeI';

$manger       = "@FOR0OB";    #Manger username
$IDcontrol    = 1623464157;   #Manger ID

#Other mangers  usernames as '@FOR0OB','@E_G_Y_P0'
$otherMangers    = ['@FOR0OB'];

$buyBanID    = -1001705867405; #Buy and Ban Notices
$fullID            = -1001617599402; #Full completely Numbers
$fullID2         = -1001617599402; #قناة التفعيلات
$cardsID       = -1001644529285; #Notices signup and cards


?>